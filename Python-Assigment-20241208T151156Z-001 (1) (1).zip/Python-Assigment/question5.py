#odd or even

n = int(input("Enter the Number:"))
if(n % 2 == 0):{
    print("The number is even" )
}
else:
    print("The number is odd")