# Leap year checker
n=int(input("Year:"))
if n % 4 == 0:
    if n % 100 == 0:
        if n % 400 == 0:
            print("A year is Leap year")
else:
    print("A year is not Leap year")
    
            
    
