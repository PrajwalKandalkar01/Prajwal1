#Number classification
n=int(input())
if(n>0):{
    print("The number is positive")
}
if(n<0):{
    print("The number is negative")
}
if(n==0):{
    print("The number is zero")
}