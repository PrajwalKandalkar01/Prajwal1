#Grade calculator
n=int(input("Enter your score :"))
if(n>=90 and n<100):{
    print("Grade A")
}
if(n>=80 and n<89):{
    print("Grade B")
}
if(n>=70 and n<=79):{
    print("Grade C")
}
if(n>=60 and n<69):{
    print("Grade D")
}
if(n<60):{
    print("Fail")
}
    