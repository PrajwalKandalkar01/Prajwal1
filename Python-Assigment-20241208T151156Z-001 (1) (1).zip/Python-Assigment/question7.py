#Login Authentication
# Take input for username and password
username = input("Enter username: ")
password = input("Enter password: ")

# Check credentials
if username == "admin" and password == "1234":
    print("Login successful.")
else:
    print("Invalid username or password.")
