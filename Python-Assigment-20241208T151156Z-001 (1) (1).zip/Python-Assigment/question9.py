#Traffic Light Guide

light_color=input("red, yellow, green")
if(light_color == "red"):{
    print("Stop")
}
elif(light_color == "yellow"):{
    print("Get ready")
}
elif(light_color == "green"):{
    print("Go")
}
else:
    print("Invalid traffic light color.")