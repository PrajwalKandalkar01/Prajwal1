#Maximum of Three Numbers
# Input three numbers
a = int(input("Enter the first number: "))
b = int(input("Enter the second number: "))
c = int(input("Enter the third number: "))

# Compare numbers and determine the result
if a == b == c:
    print("All three numbers are the same.")
elif a == b or a == c or b == c:
    print("Two or more numbers are the same and the largest.")
else:
    print("The largest number is:", max(a, b, c))
