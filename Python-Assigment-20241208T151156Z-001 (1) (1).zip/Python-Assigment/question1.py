#Age classifier
n=int(input("age is:"))
if (n<12):{
    print("you are a child")
}
if (n>=12 and n<17):{
    print("you are a teenager")
}
if(n>=18 and n<64):{
    print("you are an adult")
}
if(n>=65):{
    print("you are a senior citizen ")
}